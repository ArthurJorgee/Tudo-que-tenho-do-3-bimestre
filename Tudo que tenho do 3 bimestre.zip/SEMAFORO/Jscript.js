document.addEventListener('DOMContentLoaded', () =>{
 
    function alternarLuzes() {
      if(estadoAtual == 'vermelho') {
  vermelho.style.backgroundColor = '#ff0000';
  amarelo.style.backgroundColor = '#555555';
  verde.style.backgroundColor = '#555555';
        estadoAtual = 'verde';
      } else if(estadoAtual == 'verde'){
  verde.style.backgroundColor = '#555555';
  amarelo.style.backgroundColor = '#fff00';
  vermelho.style.backgroundColor = '#555555';
        estadoAtual = 'amarelo';
      } else if(estadoAtual == 'amarelo'){
  verde.style.backgroundColor = '#555555';
  amarelo.style.backgroundColor = '#555555';
  vermelho.style.backgroundColor = '#00ff00';
        estadoAtual = 'vermelho';
      }
    }
    setInterval(alternarLuzes, 2000)