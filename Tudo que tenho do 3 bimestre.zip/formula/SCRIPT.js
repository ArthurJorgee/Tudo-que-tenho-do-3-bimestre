function calcularForca() {
    const constanteEletrostatica = 8.99e9; // constante de Coulomb (N·m²/C²)
    let carga1 = parseFloat(document.getElementById('carga1').value);
    let carga2 = parseFloat(document.getElementById('carga2').value);
    let distancia = parseFloat(document.getElementById('distancia').value);

    // Verificação de entradas inválidas
    if (isNaN(carga1) || isNaN(carga2) || isNaN(distancia) || distancia <= 0) {
        document.getElementById('resultado').textContent = "Insira valores válidos e a distância deve ser maior que 0";
        return;
    }

    // Cálculo da força eletrostática com a fórmula F = k * (Q1 * Q2) / d²
    let forcaEletrostatica = (constanteEletrostatica * carga1 * carga2) / Math.pow(distancia, 2);

    // Exibição do resultado
    document.getElementById('resultado').textContent = `A força eletrostática entre as cargas é de ${forcaEletrostatica.toFixed(2)} N`;

}
